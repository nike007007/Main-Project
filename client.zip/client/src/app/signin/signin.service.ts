import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { User } from '../models/user.model'; 

@Injectable()
export class SigninService {
 
    constructor(private http: HttpClient){
 
    }
     
    validateSignin(user: User){
        return this.http.post('/api/user/Signin',{
            username : user.username,
            password : user.password
        })
    }
 
}