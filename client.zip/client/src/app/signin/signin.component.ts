import { Component } from '@angular/core';
import { SigninService } from './signin.service';
import { User } from '../models/user.model';
import { Router } from '@angular/router';
 
@Component({
  selector: 'app-signin',
  templateUrl: './signin.component.html',
  styleUrls: ['./signin.component.css'],
  providers: [ SigninService ]
})
export class SigninComponent {
 
  public user : User;
 
  constructor(private signinService: SigninService, private router: Router) {
      this.user = new User();
  }
 
  validateSignin() {
    if(this.user.username && this.user.password) {
        this.signinService.validateSignin(this.user).subscribe(result => {
        console.log('result is ', result);
        if(result['status'] === 'success') {
          this.router.navigate(['/home']);
        } else {
          alert('Wrong username password');
        }
         
      }, error => {
        console.log('error is ', error);
      });
    } else {
        alert('enter user name and password');
    }
  }
 
}
