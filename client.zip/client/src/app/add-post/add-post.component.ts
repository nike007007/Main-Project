import { Component } from '@angular/core';
import { AddPostService } from './add-post.service';
import { Post } from '../models/post.model';
import { Component, ViewChild, ElementRef } from '@angular/core';
 
@Component({
  selector: 'app-add-post',
  templateUrl: './add-post.component.html',
  styleUrls: ['./add-post.component.css'],
  providers: [ AddPostService ]
})
export class AddPostComponent {
 
  public post : Post;
 
  constructor(private addPostService: AddPostService) {
      this.post = new Post();
  }
 
  @ViewChild('closeBtn') closeBtn: ElementRef;
  addPost() {
    if(this.post.title && this.post.description){
        if(this.post._id){
          this.addPostService.updatePost(this.post).subscribe(res =>{
            this.closeBtn.nativeElement.click();
            this.commonService.notifyPostAddition();
          });
        } else {
          this.addPostService.addPost(this.post).subscribe(res =>{
            this.closeBtn.nativeElement.click();
            this.commonService.notifyPostAddition();
          });
        }
    } else {
        alert('Title and Description required');
    }
}
updatePost(post: Post){
  return this.http.post('/api/post/updatePost',{
      id: post._id,
      title : post.title,
      description : post.description
  })
}
}
