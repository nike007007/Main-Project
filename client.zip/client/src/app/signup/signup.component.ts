import { Component } from '@angular/core';
import { SignupService } from './signup.service';
import { User } from '../models/register.model';
import { Router } from '@angular/router';
 
@Component({
  selector: 'app-signin',
  templateUrl: './signup.component.html',
  styleUrls: ['./signup.component.css'],
  providers: [ SignupService ]
})
export class SignupComponent {
 
  public user : User;
 
  constructor(private signupService: SignupService, private router: Router) {
      this.user = new User();
  }
 
  validateSignin() {
    if(this.user.username && this.user.password && this.user.mobileno) {
        this.signupService.validateSignup(this.user).subscribe(result => {
        console.log('result is ', result);
        if(result['status'] === 'success') {
          this.router.navigate(['/signin']);
        } else {
          alert('Wrong username password');
        }
         
      }, error => {
        console.log('error is ', error);
      });
    } else {
        alert('enter user name,password and mobileno');
    }
  }
 
}
