import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { User } from '../models/register.model'; 

@Injectable()
export class SignupService {
 
    constructor(private http: HttpClient){
 
    }
     
    validateSignup(user: User){
        return this.http.post('/api/user/Signup',{
            username : user.username,
            password : user.password,
            mobileno : user.mobileno
        })
    }
 
}