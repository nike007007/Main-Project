export class User {
    constructor(){
        this.username = '';
        this.password = '';
        this.mobileno = '';
    }
    public username;
    public password;
    public mobileno;
}