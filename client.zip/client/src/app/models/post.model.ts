export class Post {
    constructor(){
        this._id = '';
        this.title = '';
        this.description = '';
    }
    public _id;
    public title;
    public description;
}
